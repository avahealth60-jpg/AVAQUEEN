# CARA PASANG — AVA Health V1.1.0

**Fase 1.1.0 — Sistem desain premium + navigasi penuh per peran**
Patch ini bersifat **aditif**: hanya menambah file baru ke `packages/ui`, tidak menimpa file V1.0 mana pun. Aman digabung ke repo teruji (87 tes hijau) tanpa risiko regresi.

---

## Apa isi patch ini

```
packages/ui/src/
├─ tokens/                    # design token instrument-grade (sumber kebenaran tunggal)
│  ├─ colors.ts               # palette, status triase/QC/badge, resolver aman
│  ├─ scale.ts                # tipografi, spacing, radius, elevasi, motion
│  ├─ index.ts                # generateTokensCss() + re-export
│  └─ __tests__/tokens.test.ts
├─ nav/                       # navigasi PENUH per peran (jawaban "di mana input")
│  ├─ types.ts                # NavItem, Role, RoleNav
│  ├─ roles.ts                # 5 peran, transkripsi persis Blueprint V1.1 §02
│  ├─ index.ts                # navByRole, allRoles, getNav()
│  └─ __tests__/nav.test.ts
├─ signature/                 # motif tanda tangan
│  ├─ calibrationScale.ts     # generator SVG skala kalibrasi (fungsi murni)
│  └─ __tests__/calibrationScale.test.ts
├─ tokens.css                 # hasil generate generateTokensCss() (CSS variables)
└─ v110.ts                    # barrel: satu titik re-export semua di atas
```

Status QC patch ini sebelum dikirim: **34 tes hijau · typecheck strict bersih (exit 0)**.

---

## Langkah pasang (Windows / PowerShell 5.1)

> Catatan PowerShell 5.1: **jangan** pakai `&&` untuk merangkai perintah. Jalankan baris per baris.

### 1. Ekstrak patch ke root repo

Ekstrak `ava-v1.1.0-patch.zip` di **root** monorepo `ava-health/`. Folder `packages/ui/src/...` akan menyatu otomatis dengan struktur yang sudah ada.

```powershell
Expand-Archive -Path .\ava-v1.1.0-patch.zip -DestinationPath . -Force
```

### 2. Sambungkan barrel ke index `packages/ui` yang sudah ada

Buka `packages/ui/src/index.ts` (file index existing-mu), tambahkan **satu baris** di bawah ekspor yang sudah ada:

```ts
export * from './v110.js';
```

> Jika `index.ts`-mu memakai ekspor tanpa ekstensi `.js`, samakan gayanya: `export * from './v110';`

### 3. Impor token CSS sekali per app

Di file root layout tiap app (`apps/customer`, `apps/partner`, `apps/admin`) — biasanya `app/layout.tsx` — impor token CSS satu kali:

```ts
import '@ava/ui/src/tokens.css';
```

> Sesuaikan path dengan konfigurasi export `@ava/ui`-mu. Kalau `@ava/ui` mengekspor CSS lewat `package.json#exports`, pakai jalur itu. Tujuannya: blok `:root { --ava-* }` termuat di setiap app.

### 4. Pasang font (instrument-grade)

Sistem desain memakai tiga font open-source (selaras prinsip standar terbuka — bisa di-self-host, tanpa lock-in):

- **Space Grotesk** — display/judul
- **Inter** — body/UI
- **JetBrains Mono** — angka, parameter, ambang, serial, kode badge

Cara tercepat (Next.js App Router, `apps/*/app/layout.tsx`):

```ts
import { Inter, Space_Grotesk, JetBrains_Mono } from 'next/font/google';

const inter = Inter({ subsets: ['latin'], variable: '--ava-font-body' });
const display = Space_Grotesk({ subsets: ['latin'], variable: '--ava-font-display' });
const mono = JetBrains_Mono({ subsets: ['latin'], variable: '--ava-font-mono' });
// pasang className `${inter.variable} ${display.variable} ${mono.variable}` di <html>
```

> Untuk produksi self-host Indonesia, unduh ketiga font dan layani lokal — sama prinsipnya, tanpa CDN eksternal.

### 5. Verifikasi

Jalankan satu per satu (PowerShell):

```powershell
pnpm --filter @ava/ui test
```
```powershell
pnpm --filter @ava/ui typecheck
```
```powershell
pnpm build
```

> Pakai `npm`/`yarn` bila itu package manager-mu; ganti `pnpm --filter @ava/ui` sesuai setup. Yang penting: tes `packages/ui` bertambah **+34** dan tetap hijau, typecheck bersih, build sukses.

---

## Cara pakai di komponen

### Navigasi per peran (sidebar/bottom-nav)

```tsx
import { getNav } from '@ava/ui';
// role didapat dari JWT claim (auth.jwt()->>'role'); UI hanya menampilkan, RLS menegakkan.
const nav = getNav(role); // { roleLabel, tagline, items: [...] }
// nav.items: { id, label, href, icon (nama lucide), description, isNew? }
```

Tiap peran kini punya **navigasi penuh** (customer 8 menu, vendor 6, lab 5, dokter 6, admin 8) — bukan satu halaman. Label memakai kata kerja aktif ("Catat pemeriksaan", bukan "Submit").

### Motif skala kalibrasi (readout parameter & status alat)

```tsx
import { calibrationScale } from '@ava/ui';

const { svg, status } = calibrationScale({
  value: 126, scaleMin: 70, scaleMax: 200,
  normalMin: 70, normalMax: 99, unit: 'mg/dL',
});
// render: <div dangerouslySetInnerHTML={{ __html: svg }} />  (svg sudah aman, fungsi murni tanpa input HTML)
```

> **Penting (posisi SaMD):** `calibrationScale` hanya **menggambar** hasil. Penentuan triase/status tetap deterministik di `@ava/domain`. Lapisan ini presentasi murni — tidak mengubah posisi non-diagnostik.

### Token warna status

```tsx
import { resolveTriage, resolveQc } from '@ava/ui';
const t = resolveTriage('perhatian'); // { fg, bg, label: 'Perlu perhatian' }
```

---

## Yang TIDAK berubah

- Tidak ada migrasi DB pada fase ini (murni front-end/design system).
- Tidak ada file V1.0 yang ditimpa.
- Posisi non-SaMD, RLS, dan firewall liabilitas KBLI 86910 tidak tersentuh.

---

## Berikutnya (roadmap V1.1)

- **1.1.1** — Mesin pemeriksaan multi-parameter + panel + katalog parameter (data, bukan kode) → butuh migrasi DB (`checkups`, `panels`, `parameters`, `reference_ranges`) yang **idempoten & berversi**.
- **1.1.2** — Evaluasi komprehensif + basis pengetahuan terkurasi.

Kabari kalau mau saya lanjut ke **1.1.1**, atau ada penyesuaian token/navigasi dulu.
